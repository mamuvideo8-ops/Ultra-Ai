import 'dart:convert';
import 'package:http/http.dart' as http;

class GeminiModelService {
  Future<List<String>> listGenerativeModels({required String apiKey}) async {
    final key = apiKey.trim();
    if (key.isEmpty) throw const GeminiModelException('Settings में Gemini API key डालें।');

    final uri = Uri.https('generativelanguage.googleapis.com', '/v1beta/models',
        {'key': key, 'pageSize': '100'});
    final response = await http.get(uri, headers: const {'Accept': 'application/json'})
        .timeout(const Duration(seconds: 30));

    Map<String, dynamic> body;
    try {
      body = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      throw GeminiModelException('Gemini से सही response नहीं मिला (${response.statusCode})।');
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final error = body['error'];
      final message = error is Map<String, dynamic>
          ? (error['message']?.toString() ?? 'HTTP ${response.statusCode}')
          : 'HTTP ${response.statusCode}';
      throw GeminiModelException(message);
    }

    final raw = body['models'];
    if (raw is! List) return [];
    final result = <String>[];
    for (final item in raw) {
      if (item is! Map<String, dynamic>) continue;
      final name = item['name']?.toString() ?? '';
      final methods = item['supportedGenerationMethods'];
      if (name.startsWith('models/') && methods is List &&
          methods.contains('generateContent')) {
        result.add(name.substring('models/'.length));
      }
    }
    result.sort();
    return result;
  }
}

class GeminiModelException implements Exception {
  final String message;
  const GeminiModelException(this.message);
  @override
  String toString() => message;
}
