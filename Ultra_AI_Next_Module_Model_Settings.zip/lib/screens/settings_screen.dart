import 'package:flutter/material.dart';
import '../services/settings_service.dart';
import '../services/gemini_model_service.dart';
import '../services/auth_service.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _settings = SettingsService();
  final _key = TextEditingController();
  final _model = TextEditingController();
  List<String> _models = [];
  bool _loaded = false;
  bool _loadingModels = false;
  String? _modelError;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    _key.text = await _settings.getApiKey();
    _model.text = await _settings.getModel();
    if (mounted) setState(() => _loaded = true);
  }

  Future<void> _discoverModels() async {
    setState(() { _loadingModels = true; _modelError = null; });
    try {
      final models = await GeminiModelService().listGenerativeModels(apiKey: _key.text);
      if (!mounted) return;
      setState(() {
        _models = models;
        if (models.isNotEmpty && !models.contains(_model.text)) _model.text = models.first;
      });
      if (models.isEmpty) setState(() => _modelError = 'इस API key के लिए generateContent मॉडल नहीं मिले।');
    } catch (e) {
      if (mounted) setState(() => _modelError = e.toString());
    } finally {
      if (mounted) setState(() => _loadingModels = false);
    }
  }

  Future<void> _save() async {
    await _settings.setApiKey(_key.text);
    await _settings.setModel(_model.text.isEmpty ? 'gemini-2.5-flash' : _model.text);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Gemini settings save हो गईं।')));
  }

  @override
  void dispose() {
    _key.dispose();
    _model.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Settings')),
    body: !_loaded ? const Center(child: CircularProgressIndicator()) :
    ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Gemini connection', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      TextField(controller: _key, obscureText: true,
        decoration: const InputDecoration(labelText: 'Gemini API key', hintText: 'Paste your API key')),
      const SizedBox(height: 12),
      OutlinedButton.icon(
        onPressed: _loadingModels ? null : _discoverModels,
        icon: _loadingModels
          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
          : const Icon(Icons.manage_search),
        label: Text(_loadingModels ? 'मॉडल खोज रहे हैं…' : 'मेरे उपलब्ध Gemini मॉडल खोजें')),
      if (_modelError != null) Padding(
        padding: const EdgeInsets.only(top: 8),
        child: Text(_modelError!, style: const TextStyle(color: Colors.red))),
      const SizedBox(height: 12),
      if (_models.isNotEmpty) DropdownButtonFormField<String>(
        value: _models.contains(_model.text) ? _model.text : null,
        decoration: const InputDecoration(labelText: 'Available Gemini model'),
        items: _models.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
        onChanged: (value) { if (value != null) setState(() => _model.text = value); },
      ) else TextField(controller: _model,
        decoration: const InputDecoration(labelText: 'Model ID', hintText: 'gemini-2.5-flash')),
      const SizedBox(height: 8),
      const Text('मॉडल की उपलब्धता API key और region पर निर्भर करती है। API key को सार्वजनिक GitHub में अपलोड न करें।',
        style: TextStyle(color: AppTheme.muted)),
      const SizedBox(height: 18),
      FilledButton(onPressed: _save, child: const Text('Save settings')),
      const Divider(height: 36),
      const Text('Account', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      OutlinedButton.icon(
        onPressed: () async {
          try {
            await AuthService().signInWithGoogle();
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Google sign-in request complete')));
          } catch (e) {
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Sign-in setup required: $e')));
          }
        },
        icon: const Icon(Icons.login), label: const Text('Continue with Google')),
      const Divider(height: 36),
      const Text('Plans', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const ListTile(leading: Icon(Icons.lock_open), title: Text('Free plan'), subtitle: Text('Basic access.')),
      const ListTile(leading: Icon(Icons.workspace_premium), title: Text('Ultra AI Premium'),
        subtitle: Text('Paid subscription needs Google Play Billing setup.')),
    ]),
  );
}
