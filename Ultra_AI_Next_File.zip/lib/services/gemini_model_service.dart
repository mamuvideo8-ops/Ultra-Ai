import 'dart:convert';
import 'package:http/http.dart' as http;

/// Lists Gemini models available to the supplied API key.
///
/// The API key is passed at runtime and is never hard-coded in this source.
/// For a public production app, call this service from a secured backend
/// rather than exposing users' keys or a shared key in a distributed client.
class GeminiModelService {
  static const String _baseUrl = 'https://generativelanguage.googleapis.com';

  Future<List<String>> listGenerativeModels({
    required String apiKey,
  }) async {
    final key = apiKey.trim();
    if (key.isEmpty) {
      throw const GeminiModelException('Please add your Gemini API key in Settings.');
    }

    final uri = Uri.https(
      'generativelanguage.googleapis.com',
      '/v1beta/models',
      {'key': key, 'pageSize': '100'},
    );

    final response = await http.get(
      uri,
      headers: const {'Accept': 'application/json'},
    ).timeout(const Duration(seconds: 30));

    final Map<String, dynamic> body;
    try {
      body = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      throw GeminiModelException(
        'Gemini returned an unreadable response (HTTP ${response.statusCode}).',
      );
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final error = body['error'];
      final message = error is Map<String, dynamic>
          ? (error['message']?.toString() ?? 'HTTP ${response.statusCode}')
          : 'HTTP ${response.statusCode}';
      throw GeminiModelException(message);
    }

    final rawModels = body['models'];
    if (rawModels is! List) return <String>[];

    final models = <String>[];
    for (final item in rawModels) {
      if (item is! Map<String, dynamic>) continue;

      final name = item['name']?.toString() ?? '';
      final methods = item['supportedGenerationMethods'];
      final supportsGenerateContent =
          methods is List && methods.contains('generateContent');

      if (name.startsWith('models/') && supportsGenerateContent) {
        final modelId = name.substring('models/'.length);
        if (modelId.isNotEmpty) models.add(modelId);
      }
    }

    models.sort();
    return models;
  }
}

class GeminiModelException implements Exception {
  final String message;
  const GeminiModelException(this.message);

  @override
  String toString() => message;
}
