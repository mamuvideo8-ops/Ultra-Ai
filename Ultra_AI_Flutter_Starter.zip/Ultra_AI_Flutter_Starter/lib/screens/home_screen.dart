import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/chat_message.dart';
import '../services/gemini_service.dart';
import '../services/history_service.dart';
import '../services/settings_service.dart';
import '../services/voice_service.dart';
import '../theme/app_theme.dart';
import 'settings_screen.dart';
import 'camera_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _controller = TextEditingController();
  final _scroll = ScrollController();
  final _settings = SettingsService();
  final _history = HistoryService();
  final _gemini = GeminiService();
  final _voice = VoiceService();
  final _picker = ImagePicker();
  final List<ChatMessage> _messages = [];
  bool _busy = false;
  File? _image;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final items = await _history.load();
    if (mounted) setState(() => _messages.addAll(items));
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if ((text.isEmpty && _image == null) || _busy) return;
    _controller.clear();
    final userMessage = ChatMessage(role: 'user', text: text.isEmpty ? 'इस तस्वीर को समझाओ।' : text);
    setState(() { _messages.add(userMessage); _busy = true; });
    try {
      final key = await _settings.getApiKey();
      final model = await _settings.getModel();
      final image = _image;
      final history = List<ChatMessage>.from(_messages);
      final reply = await _gemini.sendMessage(
        apiKey: key, model: model, history: history,
        imageBase64: image == null ? null : base64Encode(await image.readAsBytes()),
        imageMimeType: image == null ? null : 'image/jpeg',
      );
      final answer = ChatMessage(role: 'assistant', text: reply);
      setState(() => _messages.add(answer));
      await _history.save(_messages);
      await _voice.speak(reply);
    } catch (e) {
      setState(() => _messages.add(ChatMessage(role: 'assistant', text: 'त्रुटि: $e')));
    } finally {
      setState(() { _busy = false; _image = null; });
    }
  }

  Future<void> _pickImage() async {
    final file = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (file != null) setState(() => _image = File(file.path));
  }

  Future<void> _listen() async {
    final ok = await _voice.startListening((words) {
      if (mounted) setState(() => _controller.text = words);
    });
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Speech permission या service उपलब्ध नहीं है।')));
    }
  }

  void _newChat() async {
    await _history.clear();
    setState(() { _messages.clear(); _image = null; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: SafeArea(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Padding(padding: EdgeInsets.all(20), child: Text('Ultra AI', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
          _nav(Icons.image_outlined, 'Images', _pickImage),
          _nav(Icons.collections_bookmark_outlined, 'Library', () => _info('Library sync अगली चरण में जोड़ी जाएगी।')),
          _nav(Icons.tune, 'Customize', () => _info('Customize विकल्प Settings में उपलब्ध होंगे।')),
          _nav(Icons.folder_open, 'Projects', () => _info('Projects अगली चरण में जोड़े जाएँगे।')),
          _nav(Icons.screen_share_outlined, 'Remote / Screen Share', () => _info('Android MediaProjection integration अगली चरण में आवश्यक है।')),
          _nav(Icons.explore_outlined, 'Explore', () => _info('Explore में उपलब्ध मॉडल और टूल दिखेंगे।')),
          const Divider(),
          const Padding(padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8), child: Text('Recent chats')),
          Expanded(child: ListView(children: _messages.where((m) => m.role == 'user').take(12).map((m) =>
            ListTile(dense: true, leading: const Icon(Icons.chat_bubble_outline), title: Text(m.text, maxLines: 1, overflow: TextOverflow.ellipsis))
          ).toList())),
          _nav(Icons.add_comment_outlined, 'New chat', _newChat),
          _nav(Icons.settings_outlined, 'Settings', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()))),
        ])),
      ),
      appBar: AppBar(
        leading: Builder(builder: (context) => IconButton(icon: const Icon(Icons.menu), onPressed: () => Scaffold.of(context).openDrawer())),
        title: const Text('✦ Ultra AI', style: TextStyle(color: AppTheme.blue, fontWeight: FontWeight.bold)),
        actions: [IconButton(icon: const Icon(Icons.account_circle_outlined, size: 30), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())))],
      ),
      body: Column(children: [
        Expanded(child: _messages.isEmpty
          ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: const [
              Icon(Icons.auto_awesome, size: 48, color: AppTheme.blue),
              SizedBox(height: 14),
              Text('What can I help with?', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w600)),
              SizedBox(height: 8),
              Text('Ask anything, or share an image.', style: TextStyle(color: AppTheme.muted)),
            ]))
          : ListView.builder(controller: _scroll, padding: const EdgeInsets.all(16), itemCount: _messages.length + (_busy ? 1 : 0), itemBuilder: (context, i) {
              if (i == _messages.length) return const Padding(padding: EdgeInsets.all(12), child: LinearProgressIndicator());
              final m = _messages[i];
              final user = m.role == 'user';
              return Align(alignment: user ? Alignment.centerRight : Alignment.centerLeft, child: Container(
                constraints: const BoxConstraints(maxWidth: 330),
                margin: const EdgeInsets.symmetric(vertical: 6),
                padding: const EdgeInsets.all(13),
                decoration: BoxDecoration(color: user ? const Color(0xFFEAF1FF) : Colors.white, borderRadius: BorderRadius.circular(18)),
                child: Text(m.text),
              ));
            })),
        if (_image != null) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Row(children: [
          const Icon(Icons.image), const SizedBox(width: 8), Expanded(child: Text(_image!.path.split('/').last, overflow: TextOverflow.ellipsis)),
          IconButton(onPressed: () => setState(() => _image = null), icon: const Icon(Icons.close)),
        ])),
        Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 16), child: Row(children: [
          IconButton(onPressed: _pickImage, icon: const Icon(Icons.add, size: 28)),
          Expanded(child: TextField(controller: _controller, minLines: 1, maxLines: 4, decoration: const InputDecoration(hintText: 'Message Ultra AI'))),
          IconButton(onPressed: _listen, icon: const Icon(Icons.mic_none, size: 27)),
          IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CameraScreen())), icon: const Icon(Icons.camera_alt_outlined)),
          IconButton(onPressed: _busy ? null : _send, icon: const Icon(Icons.arrow_upward, color: Colors.white), style: IconButton.styleFrom(backgroundColor: AppTheme.blue)),
        ])),
      ]),
    );
  }

  Widget _nav(IconData icon, String title, VoidCallback action) =>
      ListTile(leading: Icon(icon), title: Text(title), onTap: () { Navigator.pop(context); action(); });

  void _info(String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}
