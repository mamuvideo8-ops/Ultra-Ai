import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});
  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  CameraController? _controller;
  bool _error = false;

  @override
  void initState() {
    super.initState();
    _initCamera();
  }

  Future<void> _initCamera() async {
    try {
      final cameras = await availableCameras();
      final back = cameras.where((c) => c.lensDirection == CameraLensDirection.back);
      if (cameras.isEmpty) throw Exception('No camera found');
      _controller = CameraController(back.isNotEmpty ? back.first : cameras.first, ResolutionPreset.medium, enableAudio: false);
      await _controller!.initialize();
      if (mounted) setState(() {});
    } catch (_) {
      if (mounted) setState(() => _error = true);
    }
  }

  @override
  void dispose() { _controller?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Back camera preview')),
    body: Center(child: _error
      ? const Text('Camera unavailable. Check camera permission.')
      : _controller == null || !_controller!.value.isInitialized
        ? const CircularProgressIndicator()
        : AspectRatio(aspectRatio: _controller!.value.aspectRatio, child: CameraPreview(_controller!))),
  );
}
