import 'package:flutter/material.dart';
import '../services/settings_service.dart';
import '../services/auth_service.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _settings = SettingsService();
  final _key = TextEditingController();
  final _model = TextEditingController();
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    _key.text = await _settings.getApiKey();
    _model.text = await _settings.getModel();
    if (mounted) setState(() => _loaded = true);
  }

  @override
  void dispose() { _key.dispose(); _model.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Settings')),
    body: !_loaded ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Gemini connection', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      TextField(controller: _key, obscureText: true, decoration: const InputDecoration(labelText: 'Gemini API key', hintText: 'Paste your API key')),
      const SizedBox(height: 12),
      TextField(controller: _model, decoration: const InputDecoration(labelText: 'Model ID', hintText: 'gemini-2.5-flash')),
      const SizedBox(height: 8),
      const Text('मॉडल ID आपके API key और क्षेत्र में उपलब्ध होना चाहिए। API key को सार्वजनिक GitHub में अपलोड न करें।', style: TextStyle(color: AppTheme.muted)),
      const SizedBox(height: 18),
      FilledButton(onPressed: () async {
        await _settings.setApiKey(_key.text);
        await _settings.setModel(_model.text.isEmpty ? 'gemini-2.5-flash' : _model.text);
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Settings saved')));
      }, child: const Text('Save settings')),
      const Divider(height: 36),
      const Text('Account', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      OutlinedButton.icon(onPressed: () async {
        try {
          await AuthService().signInWithGoogle();
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Google sign-in complete')));
        } catch (e) {
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Sign-in setup required: $e')));
        }
      }, icon: const Icon(Icons.login), label: const Text('Continue with Google')),
      const Divider(height: 36),
      const Text('Plans', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const ListTile(leading: Icon(Icons.lock_open), title: Text('Free plan'), subtitle: Text('Basic access. Premium billing will be configured after Play Console setup.')),
      const ListTile(leading: Icon(Icons.workspace_premium), title: Text('Ultra AI Premium'), subtitle: Text('Paid subscription — not active until Google Play Billing is integrated.')),
    ]),
  );
}
