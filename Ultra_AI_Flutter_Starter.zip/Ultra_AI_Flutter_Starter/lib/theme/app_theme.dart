import 'package:flutter/material.dart';

class AppTheme {
  static const blue = Color(0xFF3267E9);
  static const ink = Color(0xFF171717);
  static const muted = Color(0xFF777777);

  static ThemeData get light => ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: const Color(0xFFFAFAFA),
    colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.light),
    appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFFAFAFA), elevation: 0),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      hintStyle: const TextStyle(color: Colors.grey),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
    ),
  );
}
