import 'package:shared_preferences/shared_preferences.dart';

class SettingsService {
  static const _apiKeyKey = 'gemini_api_key';
  static const _modelKey = 'gemini_model';

  Future<String> getApiKey() async =>
      (await SharedPreferences.getInstance()).getString(_apiKeyKey) ?? '';

  Future<void> setApiKey(String value) async =>
      (await SharedPreferences.getInstance()).setString(_apiKeyKey, value.trim());

  Future<String> getModel() async =>
      (await SharedPreferences.getInstance()).getString(_modelKey) ?? 'gemini-2.5-flash';

  Future<void> setModel(String value) async =>
      (await SharedPreferences.getInstance()).setString(_modelKey, value.trim());
}
