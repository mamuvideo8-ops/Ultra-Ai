import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';

class VoiceService {
  final SpeechToText _speech = SpeechToText();
  final FlutterTts _tts = FlutterTts();

  Future<bool> startListening(void Function(String) onText) async {
    final available = await _speech.initialize();
    if (!available) return false;
    await _speech.listen(onResult: (result) => onText(result.recognizedWords));
    return true;
  }

  Future<void> stopListening() => _speech.stop();
  Future<void> speak(String text) async {
    await _tts.setLanguage('en-US');
    await _tts.speak(text);
  }
  Future<void> stopSpeaking() => _tts.stop();
}
