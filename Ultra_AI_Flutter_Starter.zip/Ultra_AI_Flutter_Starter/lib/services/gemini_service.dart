import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/chat_message.dart';

class GeminiService {
  Future<String> sendMessage({
    required String apiKey,
    required String model,
    required List<ChatMessage> history,
    String? imageBase64,
    String? imageMimeType,
  }) async {
    if (apiKey.trim().isEmpty) {
      throw Exception('Settings में अपनी Gemini API key डालें।');
    }
    final uri = Uri.https(
      'generativelanguage.googleapis.com',
      '/v1beta/models/$model:generateContent',
      {'key': apiKey},
    );

    final contents = <Map<String, dynamic>>[];
    for (final message in history) {
      final parts = <Map<String, dynamic>>[{'text': message.text}];
      if (message.role == 'user' && imageBase64 != null && contents.isEmpty) {
        parts.add({'inlineData': {
          'mimeType': imageMimeType ?? 'image/jpeg',
          'data': imageBase64,
        }});
      }
      contents.add({
        'role': message.role == 'assistant' ? 'model' : 'user',
        'parts': parts,
      });
    }

    final response = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'contents': contents,
        'generationConfig': {'temperature': 0.7, 'maxOutputTokens': 2048},
      }),
    ).timeout(const Duration(seconds: 60));

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final message = data['error']?['message'] ?? 'Gemini request failed (${response.statusCode})';
      throw Exception(message);
    }
    final candidates = data['candidates'] as List? ?? [];
    if (candidates.isEmpty) throw Exception('Gemini ने कोई जवाब नहीं दिया।');
    final parts = candidates.first['content']?['parts'] as List? ?? [];
    return parts.map((p) => p['text'] ?? '').join().trim();
  }
}
