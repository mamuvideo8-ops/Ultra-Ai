class ChatMessage {
  final String role;
  final String text;
  final DateTime createdAt;

  ChatMessage({required this.role, required this.text, DateTime? createdAt})
      : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toJson() => {
    'role': role, 'text': text, 'createdAt': createdAt.toIso8601String()
  };

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
    role: json['role'] as String? ?? 'user',
    text: json['text'] as String? ?? '',
    createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
  );
}
