# Ultra AI — Flutter Android starter

This repository contains the Flutter app source for the first Ultra AI MVP.

## Included in this starter
- Chat interface inspired by the supplied reference screenshots
- Gemini text and image-understanding requests (using the Gemini REST `generateContent` endpoint)
- User-configurable Gemini API key and model ID
- Local chat history on the device
- Speech-to-text input and text-to-speech response
- Gallery image attachment
- Back-camera live preview
- Google sign-in code scaffold

## Important feature status
This is a starter/MVP, not a finished commercial app:
- **Screen sharing:** not implemented yet. Android screen capture requires a foreground service and MediaProjection consent flow.
- **Google sign-in:** requires Firebase project setup, Android package registration, SHA fingerprints, `google-services.json`, and Firebase initialization. The current source intentionally does not contain private project credentials.
- **Cloud chat sync / Library / Projects:** not implemented yet.
- **Paid plans:** not implemented. Google Play Billing, server-side purchase validation, subscription entitlement handling, and a Play Console product are required.
- **Image generation:** image understanding is wired through Gemini multimodal input. Actual image generation must be connected to an image-generation model/API that is enabled for your account; not every Gemini model returns images.
- **Production security:** do not ship a shared API key inside the app. For a public app, proxy Gemini calls through a secured backend with per-user quotas, abuse protection, and secret storage.

## Create the Android platform folder
Install Flutter SDK and Android Studio, then run:

```bash
flutter create --platforms=android .
flutter pub get
flutter run
```

If the Android folder already exists in your Flutter project, do not overwrite it.

## Configure Android permissions
In `android/app/src/main/AndroidManifest.xml`, inside the `<manifest>` element, add:

```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.CAMERA"/>
<uses-permission android:name="android.permission.RECORD_AUDIO"/>
```

The camera plugin may add camera permission metadata itself, but verify the merged manifest before release.

## Run
1. Open Settings in the app.
2. Paste your Gemini API key.
3. Set a model ID that is available to your API key, for example `gemini-2.5-flash` if enabled for your account.
4. Save settings and start chatting.

## GitHub safety
Never commit API keys, Firebase service files, signing keys, or passwords. This repository includes `.gitignore` entries for common secrets.
