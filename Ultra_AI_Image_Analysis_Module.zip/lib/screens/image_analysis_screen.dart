import 'dart:io';

import 'package:flutter/material.dart';

import '../services/gemini_image_analysis_service.dart';

/// Analyze a File selected by the app's CameraGalleryScreen.
class ImageAnalysisScreen extends StatefulWidget {
  const ImageAnalysisScreen({
    super.key,
    required this.apiKey,
    required this.imageFile,
    this.model = 'gemini-2.5-flash',
  });

  final String apiKey;
  final File imageFile;
  final String model;

  @override
  State<ImageAnalysisScreen> createState() => _ImageAnalysisScreenState();
}

class _ImageAnalysisScreenState extends State<ImageAnalysisScreen> {
  late final GeminiImageAnalysisService _service;
  final TextEditingController _promptController = TextEditingController(
    text: 'اس تصویر میں کیا ہے؟ تفصیل سے بتائیں۔',
  );

  bool _loading = false;
  String? _answer;
  String? _error;

  @override
  void initState() {
    super.initState();
    _service = GeminiImageAnalysisService(
      apiKey: widget.apiKey,
      model: widget.model,
    );
  }

  Future<void> _analyze() async {
    if (_loading) return;
    setState(() {
      _loading = true;
      _error = null;
      _answer = null;
    });

    try {
      final result = await _service.analyzeImage(
        image: widget.imageFile,
        prompt: _promptController.text.trim().isEmpty
            ? 'Describe this image.'
            : _promptController.text.trim(),
      );
      if (!mounted) return;
      setState(() => _answer = result);
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = error.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _promptController.dispose();
    _service.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Image Analysis')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.file(
                widget.imageFile,
                height: 250,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) =>
                    const SizedBox(
                      height: 180,
                      child: Center(child: Text('تصویر نہیں دکھائی جا سکی۔')),
                    ),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _promptController,
              minLines: 2,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: 'AI سے کیا پوچھنا ہے؟',
                hintText: 'مثلاً: اس تصویر کی وضاحت کریں',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: _loading ? null : _analyze,
              icon: const Icon(Icons.auto_awesome),
              label: const Text('Analyze Image'),
            ),
            if (_loading) ...[
              const SizedBox(height: 16),
              const Center(child: CircularProgressIndicator()),
              const Center(child: Text('Gemini تصویر سمجھ رہا ہے…')),
            ],
            if (_error != null) ...[
              const SizedBox(height: 16),
              Text(_error!, style: TextStyle(
                color: Theme.of(context).colorScheme.error,
              )),
            ],
            if (_answer != null) ...[
              const SizedBox(height: 18),
              Text('AI کا جواب', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              SelectableText(_answer!),
            ],
          ],
        ),
      ),
    );
  }
}
