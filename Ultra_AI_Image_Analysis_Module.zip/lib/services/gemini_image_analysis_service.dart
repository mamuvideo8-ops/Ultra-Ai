import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

/// Sends a user-selected image to Gemini for analysis.
/// The API key is supplied by the app; do not hard-code it in source code.
class GeminiImageAnalysisService {
  GeminiImageAnalysisService({
    required this.apiKey,
    this.model = 'gemini-2.5-flash',
    http.Client? client,
  }) : _client = client ?? http.Client();

  final String apiKey;
  final String model;
  final http.Client _client;

  String _mimeTypeFor(File file) {
    final path = file.path.toLowerCase();
    if (path.endsWith('.png')) return 'image/png';
    if (path.endsWith('.webp')) return 'image/webp';
    if (path.endsWith('.gif')) return 'image/gif';
    return 'image/jpeg';
  }

  Future<String> analyzeImage({
    required File image,
    String prompt = 'Describe this image clearly and accurately.',
  }) async {
    if (apiKey.trim().isEmpty) {
      throw Exception('Please add your Gemini API key in Settings.');
    }
    if (!await image.exists()) {
      throw Exception('The selected image file could not be found.');
    }

    final bytes = await image.readAsBytes();
    if (bytes.isEmpty) throw Exception('The selected image is empty.');

    final uri = Uri.https(
      'generativelanguage.googleapis.com',
      '/v1beta/models/$model:generateContent',
      {'key': apiKey},
    );

    final response = await _client.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'contents': [
          {
            'parts': [
              {'text': prompt},
              {
                'inlineData': {
                  'mimeType': _mimeTypeFor(image),
                  'data': base64Encode(bytes),
                }
              }
            ]
          }
        ],
        'generationConfig': {
          'temperature': 0.4,
          'maxOutputTokens': 1024,
        }
      }),
    );

    final Map<String, dynamic> data;
    try {
      data = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      throw Exception('Gemini returned an unreadable response.');
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final error = data['error'];
      final message = error is Map ? error['message'] : null;
      throw Exception(message?.toString() ??
          'Gemini request failed (${response.statusCode}).');
    }

    final candidates = data['candidates'];
    if (candidates is List && candidates.isNotEmpty) {
      final content = candidates.first['content'];
      final parts = content is Map ? content['parts'] : null;
      if (parts is List) {
        final textParts = parts
            .whereType<Map>()
            .map((part) => part['text'])
            .whereType<String>()
            .toList();
        if (textParts.isNotEmpty) return textParts.join('\n');
      }
    }
    throw Exception('Gemini did not return an analysis. Try another prompt.');
  }

  void dispose() {
    _client.close();
  }
}
