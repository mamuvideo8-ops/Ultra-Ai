# Ultra AI – Gemini Image Analysis Module

## Included files
- `lib/services/gemini_image_analysis_service.dart`
- `lib/screens/image_analysis_screen.dart`

## Dependency
Add this to `pubspec.yaml` if it is not already present:
```yaml
dependencies:
  http: ^1.2.2
```
Then run:
```bash
flutter pub get
```

## Open it after selecting a photo
For example, from the `CameraGalleryScreen` callback:
```dart
onImageSelected: (imageFile) {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => ImageAnalysisScreen(
        apiKey: yourGeminiApiKey,
        imageFile: imageFile,
        model: 'gemini-2.5-flash',
      ),
    ),
  );
},
```
Replace `yourGeminiApiKey` with the value retrieved from your app's settings
or secure configuration. Do not paste a real API key into public source code
or commit it to GitHub.

## What it does
- Shows the selected image.
- Lets the user type a question about the image.
- Sends the image and prompt to the Gemini `generateContent` API.
- Displays Gemini's text response.

## Important
- The selected Gemini model and API key must support image input and
  `generateContent`. Change the model if it is unavailable for your key.
- This is image understanding, not image generation.
- For a public production app, do not rely on an API key embedded in the APK;
  use a secured backend/proxy with usage limits.
- This module has not been compiled or tested with Flutter in this environment.
