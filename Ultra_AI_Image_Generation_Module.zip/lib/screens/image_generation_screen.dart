import 'dart:typed_data';

import 'package:flutter/material.dart';

/// Image generation screen. Connect [onGenerate] to GeminiImageService.
class ImageGenerationScreen extends StatefulWidget {
  const ImageGenerationScreen({
    super.key,
    required this.onGenerate,
  });

  final Future<Uint8List> Function(String prompt) onGenerate;

  @override
  State<ImageGenerationScreen> createState() => _ImageGenerationScreenState();
}

class _ImageGenerationScreenState extends State<ImageGenerationScreen> {
  final TextEditingController _promptController = TextEditingController();
  Uint8List? _imageBytes;
  bool _isGenerating = false;
  String? _errorMessage;

  Future<void> _generate() async {
    final prompt = _promptController.text.trim();
    if (prompt.isEmpty || _isGenerating) return;

    FocusScope.of(context).unfocus();
    setState(() {
      _isGenerating = true;
      _errorMessage = null;
      _imageBytes = null;
    });

    try {
      final bytes = await widget.onGenerate(prompt);
      if (!mounted) return;
      setState(() => _imageBytes = bytes);
    } catch (error) {
      if (!mounted) return;
      setState(() => _errorMessage = error.toString());
    } finally {
      if (mounted) setState(() => _isGenerating = false);
    }
  }

  @override
  void dispose() {
    _promptController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Image Generator')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextField(
              controller: _promptController,
              minLines: 3,
              maxLines: 6,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Describe the picture',
                hintText: 'Example: A peaceful mountain landscape at sunrise',
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: _isGenerating ? null : _generate,
              icon: const Icon(Icons.auto_awesome),
              label: Text(_isGenerating ? 'Generating…' : 'Generate image'),
            ),
            if (_isGenerating) ...[
              const SizedBox(height: 24),
              const Center(child: CircularProgressIndicator()),
              const SizedBox(height: 8),
              const Text(
                'Please wait while the image is generated.',
                textAlign: TextAlign.center,
              ),
            ],
            if (_errorMessage != null) ...[
              const SizedBox(height: 16),
              Text(
                _errorMessage!,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ],
            if (_imageBytes != null) ...[
              const SizedBox(height: 20),
              Text('Generated image',
                  style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.memory(
                  _imageBytes!,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) =>
                      const Text('Could not display the generated image.'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
