import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

/// Calls a Gemini model that supports image output.
///
/// The model name must be available to the user's API key and support image
/// generation. The service returns the first generated image it finds.
class GeminiImageService {
  GeminiImageService({
    required this.apiKey,
    required this.model,
    http.Client? client,
  }) : _client = client ?? http.Client();

  final String apiKey;
  final String model;
  final http.Client _client;

  Future<Uint8List> generateImage(String prompt) async {
    if (apiKey.trim().isEmpty) {
      throw const GeminiImageException('Gemini API key is missing.');
    }
    if (model.trim().isEmpty) {
      throw const GeminiImageException('Image model name is missing.');
    }
    if (prompt.trim().isEmpty) {
      throw const GeminiImageException('Please enter an image description.');
    }

    final uri = Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/'
      '${Uri.encodeComponent(model)}:generateContent',
    ).replace(queryParameters: {'key': apiKey});

    final body = {
      'contents': [
        {
          'parts': [
            {'text': prompt.trim()},
          ],
        },
      ],
      'generationConfig': {
        'responseModalities': ['TEXT', 'IMAGE'],
      },
    };

    late final http.Response response;
    try {
      response = await _client.post(
        uri,
        headers: const {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );
    } catch (error) {
      throw GeminiImageException('Network request failed: $error');
    }

    Map<String, dynamic> data;
    try {
      data = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      throw GeminiImageException(
        'Gemini returned an unreadable response (${response.statusCode}).',
      );
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final errorObject = data['error'];
      final message = errorObject is Map<String, dynamic>
          ? (errorObject['message']?.toString() ?? 'Unknown API error')
          : 'Unknown API error';
      throw GeminiImageException(
        'Gemini API error ${response.statusCode}: $message',
      );
    }

    final candidates = data['candidates'];
    if (candidates is! List || candidates.isEmpty) {
      throw const GeminiImageException(
        'No image was returned. Check that the selected model supports image output.',
      );
    }

    for (final candidate in candidates) {
      if (candidate is! Map<String, dynamic>) continue;
      final content = candidate['content'];
      if (content is! Map<String, dynamic>) continue;
      final parts = content['parts'];
      if (parts is! List) continue;

      for (final part in parts) {
        if (part is! Map<String, dynamic>) continue;
        final inlineData = part['inlineData'] ?? part['inline_data'];
        if (inlineData is! Map<String, dynamic>) continue;
        final encoded = inlineData['data'];
        if (encoded is String && encoded.isNotEmpty) {
          try {
            return base64Decode(encoded);
          } catch (_) {
            throw const GeminiImageException(
              'The image data from Gemini could not be decoded.',
            );
          }
        }
      }
    }

    throw const GeminiImageException(
      'Gemini returned text but no image. Try a model that supports image generation.',
    );
  }

  void close() => _client.close();
}

class GeminiImageException implements Exception {
  const GeminiImageException(this.message);

  final String message;

  @override
  String toString() => message;
}
