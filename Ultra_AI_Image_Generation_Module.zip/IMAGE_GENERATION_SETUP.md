# Ultra AI – Image Generation Module

## Included files
- `lib/services/gemini_image_service.dart`
- `lib/screens/image_generation_screen.dart`

The service requests image output from a Gemini model and returns image bytes.
The screen accepts a prompt and displays the returned image.

## Dependency
Ensure `http` is listed in `pubspec.yaml`, then run:
```bash
flutter pub get
```

## Connect the screen
```dart
final imageService = GeminiImageService(
  apiKey: yourGeminiApiKey,
  model: yourImageGenerationModel,
);

Navigator.push(
  context,
  MaterialPageRoute(
    builder: (_) => ImageGenerationScreen(
      onGenerate: imageService.generateImage,
    ),
  ),
);
```
Import both files from their `services/` and `screens/` paths.

## Important model and security notes
- Not every Gemini model can generate images. Choose an image-generation model
  that is enabled for the user's API key and supports `generateContent` with
  `responseModalities: ["TEXT", "IMAGE"]`.
- Availability, model names, quotas, and pricing can change. If the API reports
  that the model or response modality is unsupported, select a currently
  supported image-generation model in your app settings.
- Do not put a real API key in public GitHub code. A production app should use
  a protected backend rather than shipping the key inside the APK.
- This module displays the generated image in the app. Saving/sharing images
  to the phone gallery is not included yet.
- Generated code has not been compiled or tested with Flutter in this environment.
