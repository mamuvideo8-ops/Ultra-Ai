# Ultra AI – Home Screen Integration

## Included file
- `lib/screens/main_navigation_screen.dart`

This file adds bottom navigation for:
- Chat (`HomeScreen`)
- Chat History (`HistoryScreen`)
- Account (`AccountScreen`)
- Settings (`SettingsScreen`)

## Add it to your project
1. Copy `main_navigation_screen.dart` into `lib/screens/`.
2. Confirm these files exist in the same folder:
   - `home_screen.dart`
   - `history_screen.dart`
   - `account_screen.dart`
   - `settings_screen.dart`
3. In `lib/main.dart`, import:
   `import 'screens/main_navigation_screen.dart';`
4. In your `MaterialApp`, set the home page to:
   `home: const MainNavigationScreen(),`

## Important compatibility note
This integration expects each screen to have a default constructor with no required arguments.
If your existing `HistoryScreen` or another screen has a different constructor/class name,
the imports or widget calls must be adjusted to match that file.

This is a navigation integration module, not a complete APK. Firebase, Gemini API,
Android permissions, and other external setup are still separate requirements.
The code has been generated but has not been compiled or run with Flutter in this environment.
