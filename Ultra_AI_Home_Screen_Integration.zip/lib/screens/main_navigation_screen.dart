import 'package:flutter/material.dart';

import 'home_screen.dart';
import 'history_screen.dart';
import 'account_screen.dart';
import 'settings_screen.dart';

/// Main navigation shell for Ultra AI.
///
/// Assumes these existing screens have default constructors:
/// HomeScreen(), HistoryScreen(), AccountScreen(), SettingsScreen().
/// The HomeScreen remains the main chat experience.
class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _selectedIndex = 0;

  late final List<Widget> _screens = <Widget>[
    HomeScreen(),
    HistoryScreen(),
    AccountScreen(),
    SettingsScreen(),
  ];

  static const List<String> _titles = <String>[
    'Ultra AI',
    'Chat History',
    'Account',
    'Settings',
  ];

  void _selectTab(int index) {
    setState(() => _selectedIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_selectedIndex]),
        centerTitle: false,
      ),
      body: IndexedStack(
        index: _selectedIndex,
        children: _screens,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: _selectTab,
        destinations: const <NavigationDestination>[
          NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline),
            selectedIcon: Icon(Icons.chat_bubble),
            label: 'Chat',
          ),
          NavigationDestination(
            icon: Icon(Icons.history),
            label: 'History',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Account',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}
