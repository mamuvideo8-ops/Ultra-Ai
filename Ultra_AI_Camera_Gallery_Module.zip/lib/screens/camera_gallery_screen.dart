import 'dart:io';

import 'package:flutter/material.dart';

import '../services/camera_gallery_service.dart';

/// Camera and gallery picker screen for Ultra AI.
///
/// [onImageSelected] is called after the user selects or captures an image.
/// Connect that callback to the Gemini image-understanding/chat flow.
class CameraGalleryScreen extends StatefulWidget {
  const CameraGalleryScreen({
    super.key,
    this.onImageSelected,
  });

  final ValueChanged<File>? onImageSelected;

  @override
  State<CameraGalleryScreen> createState() => _CameraGalleryScreenState();
}

class _CameraGalleryScreenState extends State<CameraGalleryScreen> {
  final CameraGalleryService _mediaService = CameraGalleryService();
  File? _selectedImage;
  bool _busy = false;
  String? _message;

  Future<void> _chooseImage({required bool camera}) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _message = null;
    });

    try {
      final image = camera
          ? await _mediaService.takePhoto()
          : await _mediaService.chooseFromGallery();

      if (!mounted) return;
      if (image == null) {
        setState(() => _message = 'کوئی تصویر منتخب نہیں کی گئی۔');
      } else {
        setState(() {
          _selectedImage = image;
          _message = 'تصویر منتخب ہو گئی ہے۔';
        });
        widget.onImageSelected?.call(image);
      }
    } catch (error) {
      if (!mounted) return;
      setState(() => _message = 'تصویر کھولنے میں مسئلہ ہوا: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Camera & Gallery')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                child: Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: _selectedImage == null
                      ? const Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.image_outlined, size: 72),
                            SizedBox(height: 10),
                            Text('اپنی تصویر یہاں دیکھیں گے'),
                          ],
                        )
                      : ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: Image.file(
                            _selectedImage!,
                            width: double.infinity,
                            height: double.infinity,
                            fit: BoxFit.contain,
                            errorBuilder: (_, __, ___) =>
                                const Text('تصویر دکھائی نہیں جا سکی۔'),
                          ),
                        ),
                ),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _busy ? null : () => _chooseImage(camera: true),
                icon: const Icon(Icons.camera_alt_outlined),
                label: const Text('تصویر کھینچیں'),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: _busy ? null : () => _chooseImage(camera: false),
                icon: const Icon(Icons.photo_library_outlined),
                label: const Text('Gallery سے تصویر منتخب کریں'),
              ),
              if (_busy) ...[
                const SizedBox(height: 12),
                const Center(child: CircularProgressIndicator()),
              ],
              if (_message != null) ...[
                const SizedBox(height: 10),
                Text(_message!, textAlign: TextAlign.center),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
