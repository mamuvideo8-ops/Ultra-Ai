import 'dart:io';

import 'package:image_picker/image_picker.dart';

/// Opens the Android camera or gallery and returns the selected image file.
class CameraGalleryService {
  CameraGalleryService({ImagePicker? picker})
      : _picker = picker ?? ImagePicker();

  final ImagePicker _picker;

  Future<File?> takePhoto() async {
    final XFile? image = await _picker.pickImage(
      source: ImageSource.camera,
      imageQuality: 90,
    );
    if (image == null) return null;
    return File(image.path);
  }

  Future<File?> chooseFromGallery() async {
    final XFile? image = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 90,
    );
    if (image == null) return null;
    return File(image.path);
  }
}
