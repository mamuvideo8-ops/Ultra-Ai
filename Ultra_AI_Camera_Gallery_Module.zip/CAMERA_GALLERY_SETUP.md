# Ultra AI – Camera & Gallery Module

## Included files
- `lib/services/camera_gallery_service.dart`
- `lib/screens/camera_gallery_screen.dart`

## Dependency
Add this under `dependencies` in `pubspec.yaml` if it is not already present:
```yaml
image_picker: ^1.1.2
```
Then run:
```bash
flutter pub get
```

## Open the screen
```dart
Navigator.push(
  context,
  MaterialPageRoute(
    builder: (_) => CameraGalleryScreen(
      onImageSelected: (imageFile) {
        // Connect this File to your existing Gemini image-understanding flow.
      },
    ),
  ),
);
```

## Android notes
The `image_picker` plugin uses Android's camera/gallery intents. On supported
Android versions it generally handles the required interaction through the
plugin. Test on a real device and follow any permission/configuration guidance
for the exact plugin version you install.

## Important
- This module captures or selects one image and previews it.
- It does not yet upload the image to Gemini, save it permanently, or provide
  video recording. Connect `onImageSelected` to your existing AI image/chat
  service for image understanding.
- The code has been generated but has not been compiled or tested with Flutter
  in this environment.
