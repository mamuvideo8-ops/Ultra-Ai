# Ultra AI – Gemini Chat Integration Module

## Included file
- `lib/services/gemini_chat_service.dart`

This service sends a text prompt to Gemini and returns the model's text response.
It can also include earlier conversation turns (`user` and `model`) so replies
can use chat context.

## Dependency
Make sure `http` is already listed under `dependencies` in `pubspec.yaml`.
If it is missing, add a compatible current `http` package version, then run:

```bash
flutter pub get
```

## Example usage

```dart
final gemini = GeminiChatService(
  apiKey: yourGeminiApiKey,
  model: 'gemini-2.5-flash',
);

final answer = await gemini.sendMessage(
  prompt: 'Hello, who are you?',
  history: [
    {'role': 'user', 'text': 'Hi'},
    {'role': 'model', 'text': 'Hello! How can I help?'},
  ],
);
```

For the Voice Assistant module, pass a wrapper around `sendMessage` as its
`onAsk` callback. Do not paste a real API key into source code or public GitHub.

## Security and setup notes
- A key embedded in an Android app can be extracted. For a public release, use
  a protected server/backend and apply API restrictions and quotas.
- The selected model must be available to the API key and support
  `generateContent`. Change the model string if your account uses another model.
- This module is text chat only; it does not implement image generation,
  streaming responses, or file uploads.
- The code has been generated but not compiled or tested with Flutter here.
