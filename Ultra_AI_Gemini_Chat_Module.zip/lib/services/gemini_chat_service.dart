import 'dart:convert';
import 'package:http/http.dart' as http;

/// A small Gemini REST client for Ultra AI.
///
/// Keep the API key out of public source control. For a production app,
/// route requests through a protected backend instead of shipping the key
/// inside the mobile application.
class GeminiChatService {
  GeminiChatService({
    required this.apiKey,
    this.model = 'gemini-2.5-flash',
    http.Client? client,
  }) : _client = client ?? http.Client();

  final String apiKey;
  final String model;
  final http.Client _client;

  static const String _baseUrl =
      'https://generativelanguage.googleapis.com/v1beta/models';

  /// Sends a prompt with optional earlier conversation turns.
  ///
  /// [history] uses Gemini roles: `user` and `model`.
  /// Each item should look like:
  /// `{'role': 'user', 'text': 'Hello'}`
  Future<String> sendMessage({
    required String prompt,
    List<Map<String, String>> history = const [],
    String? systemInstruction,
  }) async {
    if (apiKey.trim().isEmpty) {
      throw const GeminiChatException('Gemini API key is missing.');
    }
    if (prompt.trim().isEmpty) {
      throw const GeminiChatException('Message cannot be empty.');
    }

    final contents = <Map<String, dynamic>>[];

    for (final item in history) {
      final role = item['role'];
      final text = item['text'];
      if ((role == 'user' || role == 'model') &&
          text != null &&
          text.trim().isNotEmpty) {
        contents.add({
          'role': role,
          'parts': [
            {'text': text},
          ],
        });
      }
    }

    contents.add({
      'role': 'user',
      'parts': [
        {'text': prompt.trim()},
      ],
    });

    final body = <String, dynamic>{
      'contents': contents,
      'generationConfig': {
        'temperature': 0.7,
        'maxOutputTokens': 2048,
      },
    };

    if (systemInstruction != null && systemInstruction.trim().isNotEmpty) {
      body['systemInstruction'] = {
        'parts': [
          {'text': systemInstruction.trim()},
        ],
      };
    }

    final uri = Uri.parse('$_baseUrl/$model:generateContent').replace(
      queryParameters: {'key': apiKey},
    );

    late final http.Response response;
    try {
      response = await _client.post(
        uri,
        headers: const {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );
    } catch (error) {
      throw GeminiChatException('Network request failed: $error');
    }

    Map<String, dynamic> data;
    try {
      data = jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      throw GeminiChatException(
        'Gemini returned an unreadable response (${response.statusCode}).',
      );
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final errorData = data['error'];
      final message = errorData is Map<String, dynamic>
          ? (errorData['message']?.toString() ?? 'Unknown API error')
          : 'Unknown API error';
      throw GeminiChatException(
        'Gemini API error ${response.statusCode}: $message',
      );
    }

    final candidates = data['candidates'];
    if (candidates is! List || candidates.isEmpty) {
      throw const GeminiChatException(
        'Gemini did not return an answer. Try another prompt.',
      );
    }

    final candidate = candidates.first;
    if (candidate is! Map<String, dynamic>) {
      throw const GeminiChatException('Gemini response format was unexpected.');
    }

    final content = candidate['content'];
    final parts = content is Map<String, dynamic> ? content['parts'] : null;
    if (parts is! List) {
      throw const GeminiChatException('Gemini response did not contain text.');
    }

    final answer = parts
        .whereType<Map<String, dynamic>>()
        .map((part) => part['text'])
        .whereType<String>()
        .join('\n')
        .trim();

    if (answer.isEmpty) {
      throw const GeminiChatException('Gemini returned an empty answer.');
    }
    return answer;
  }

  void close() {
    _client.close();
  }
}

class GeminiChatException implements Exception {
  const GeminiChatException(this.message);

  final String message;

  @override
  String toString() => message;
}
