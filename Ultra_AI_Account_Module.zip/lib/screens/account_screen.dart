import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = AuthService();

    return Scaffold(
      appBar: AppBar(title: const Text('Ultra AI Account')),
      body: StreamBuilder<User?>(
        stream: auth.authStateChanges,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final user = snapshot.data;
          if (user == null) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const CircleAvatar(
                      radius: 38,
                      child: Icon(Icons.person_outline, size: 40),
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'Sign in to Ultra AI',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Sign in with Google to connect your account. '
                      'Firebase setup is required before this can work.',
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),
                    FilledButton.icon(
                      onPressed: () => _signIn(context, auth),
                      icon: const Icon(Icons.login),
                      label: const Text('Continue with Google'),
                    ),
                  ],
                ),
              ),
            );
          }

          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Center(
                child: CircleAvatar(
                  radius: 42,
                  backgroundImage: user.photoURL == null
                      ? null
                      : NetworkImage(user.photoURL!),
                  child: user.photoURL == null
                      ? const Icon(Icons.person, size: 42)
                      : null,
                ),
              ),
              const SizedBox(height: 14),
              Center(
                child: Text(
                  user.displayName ?? 'Ultra AI user',
                  style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
                ),
              ),
              Center(child: Text(user.email ?? 'No email available')),
              const SizedBox(height: 24),
              ListTile(
                leading: const Icon(Icons.verified_user_outlined),
                title: const Text('Account status'),
                subtitle: Text(user.emailVerified ? 'Email verified' : 'Google account connected'),
              ),
              ListTile(
                leading: const Icon(Icons.fingerprint),
                title: const Text('User ID'),
                subtitle: Text(user.uid),
              ),
              const SizedBox(height: 20),
              OutlinedButton.icon(
                onPressed: () async {
                  try {
                    await auth.signOut();
                  } catch (e) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Sign out failed: $e')),
                      );
                    }
                  }
                },
                icon: const Icon(Icons.logout),
                label: const Text('Sign out'),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _signIn(BuildContext context, AuthService auth) async {
    try {
      await auth.signInWithGoogle();
    } on FirebaseException catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Firebase sign-in error: ${e.message ?? e.code}')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Sign-in could not start: $e')),
        );
      }
    }
  }
}
