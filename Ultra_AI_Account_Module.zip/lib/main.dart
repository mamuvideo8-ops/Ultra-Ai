import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Firebase must be configured in the Android project for account sign-in.
  // Keep the app launchable while Firebase setup is pending.
  try {
    await Firebase.initializeApp();
  } catch (error) {
    debugPrint('Firebase is not configured yet: $error');
  }

  runApp(const UltraAiApp());
}
