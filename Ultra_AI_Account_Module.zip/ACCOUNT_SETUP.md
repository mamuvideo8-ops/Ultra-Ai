# Ultra AI Account module

Included files:
- `lib/screens/account_screen.dart` — account/profile screen with Google sign-in state.
- `lib/services/auth_service.dart` — Firebase Authentication + Google Sign-In service.
- `lib/main.dart` — attempts Firebase initialization without blocking app startup if setup is missing.

## Required Firebase setup (not included in this ZIP)
1. Create a Firebase project.
2. Add your Android app using the exact `applicationId` from `android/app/build.gradle` or `build.gradle.kts`.
3. Enable **Authentication → Sign-in method → Google** in Firebase Console.
4. Add your Android SHA-1 and SHA-256 fingerprints in Firebase project settings.
5. Download `google-services.json` into `android/app/`.
6. Configure the Google Services Gradle plugin as instructed by the current FlutterFire setup guide.
7. Run `flutter pub get`.

Do not commit `google-services.json`, signing keys, passwords, or API secrets to a public repository.

## Connect the screen
From a screen, open it with:
```dart
Navigator.push(
  context,
  MaterialPageRoute(builder: (_) => const AccountScreen()),
);
```
Add this import:
```dart
import 'account_screen.dart';
```

This module is source code; Google sign-in will not work until Firebase and Android OAuth configuration are completed.
